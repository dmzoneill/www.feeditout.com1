<?php

include("DatabaseManager.php");

$db = DatabaseManager::getInstance( array('mysql.feeditout.com','username','password','database') );

if( isset($_GET['searchTerm']) )
{

	if( strlen($_GET['searchTerm']) ==0)
	{
		exit;
	}
	else
	{
		$term = mysql_real_escape_string($_GET['searchTerm']);
		$term2 = mysql_real_escape_string($_GET['searchTerm2']);
		$term = preg_replace( "/\(/" , "\\(" , $term );
	 	$term = preg_replace( "/\)/" , "\\)" , $term );
		$term2 = preg_replace( "/\(/" , "\\(" , $term2 );
		$term2 = preg_replace( "/\)/" , "\\)" , $term2 );

		$exp = $_GET['expr'];
		if($exp != "1" && $exp != "2")
			$exp = 1;

		$exp = ($exp == 1) ? "and" : "or";
	
		if(strlen($_GET['searchTerm2']) > 0)
		{
			if($exp == "and")
			{
				$query = "SELECT a.id, a.term, a.descript FROM SoftwareTesting a INNER JOIN SoftwareTesting b ON a.id = b.id WHERE (a.term LIKE '%$term%' AND a.descript LIKE '%$term%') AND (b.term LIKE '%$term2%' AND b.descript LIKE '%$term2%')";
				$results = $db->query($query,"array");
			}	
			else
			{
				$query = "select * from SoftwareTesting where (term like '%$term%' or descript like '%$term%') UNION select * from SoftwareTesting where (term like '%$term2%' or descript like '%$term2%') order by term ASC";
				$results = $db->query($query,"array");
			}
		}
		else
		{		
			$query = "select * from SoftwareTesting where term like '%$term%' or descript like '%$term%' order by term ASC";	
			$results = $db->query($query,"array");
		}

		print "<table class='results'>";

		$last = "";

		foreach( $results as $result )
		{
			$letter = ucfirst(substr(trim($result[1]),0,1));
			
			if( $letter != $last )
			{
				
				print "<tr><td><br /></td></tr><tr class='row'><td class='h3'> <h2 class='letter'>&nbsp;".$letter."</h2></td></tr><tr><td><br /></td></tr>";
				$last = $letter;
			}

			$syn = (substr(trim($result[2]),0,3) == "See") ? "class='dsynonyms'" : "";
			$covered = ($result[3]=="1") ? "<img src='star.png' />" : "" ;

			$title = preg_replace( "/($term)/i" , "<span class='matchh'>$term</span>" , ucfirst( $result[1] ) );

			if(substr(trim($result[2]),0,3) == "See")
			{
				$link = $result[2];	
				$link = substr( $link , 4 , strlen($link) );	
				$link = preg_match("/([a-zA-Z0-9 \-]*)/", $link, $match);
				$link = preg_replace( "/\(/" , "\\(" , $match[0] );
				$link = preg_replace( "/\)/" , "\\)" , $link );
				$def = @preg_replace( "/$link/" , "<a class='otherlink' href=\"javascript:searchExtra('$link')\">$link</a>" , $result[2] );
				$def = preg_replace( "/\\\/" , "" , $def );

				if(strlen($_GET['searchTerm2']) > 0)
				{
					$title = preg_replace("/($term2)/i","<span class='matchh'>$term2</span>",$title);
				}
			}
			else
			{	
				if ( stristr( $result[2] , "See also" ) )	
				{
					$temp = explode( "See also" , $result[2] );

					$temp[0] = preg_replace("/($term)/i","<span class='match'>$term</span>",$temp[0]);

					if(strlen($_GET['searchTerm2']) > 0)
					{
						$title = preg_replace("/($term2)/i","<span class='match'>$term2</span>",$title);
						$temp[0] = preg_replace("/($term2)/i","<span class='match'>$term2</span>",$temp[0]);
					}
					
					$def = implode( "See also" , $temp );
				}	
				else
				{
					$def = preg_replace("/($term)/i","<span class='match'>$term</span>",$result[2]);

					if(strlen($_GET['searchTerm2']) > 0)
					{
						$title = preg_replace("/($term2)/i","<span class='match'>$term2</span>",$title);
						$def = preg_replace("/($term2)/i","<span class='match'>$term2</span>",$def);
					}
				}			
			}

			if ( stristr( $def , "See also" ) )
			{						
				$seealso = explode( "See also" , $def );
				$seealso[1] = eregi_replace( "\n" , "" , $seealso[1] );

				if( stristr( $seealso[1] , "," ) )
				{				
					$alsomore = explode( "," , $seealso[1] );
			
					for( $r = 0; $r < count( $alsomore ); $r++ )
					{					
						$temp = trim($alsomore[$r]);
						$temp =  stristr( $temp , "." ) ? substr( $temp , 0 , strlen($temp) -1 ) : $temp;
						$temp = preg_replace( "/\(/" , "\\(" , $temp );
						$temp = preg_replace( "/\)/" , "\\)" , $temp );
						$alsomore[$r] = @preg_replace( "/$temp/" , "<a class='otherlink' href=\"javascript:searchExtra('$temp')\">$temp</a>" , $alsomore[$r] );
						$malso[] = preg_replace( "/\\\/" , "" , $alsomore[$r] );
					}

					$seealso[1] = implode( "," , $malso );
				}
				else
				{
					$temp = trim( $seealso[1] );
					$temp =  stristr( $temp , "." ) ? substr( $temp , 0 , strlen($temp) -1 ) : $temp;
					$temp = preg_replace( "/\(/" , "\(" , $temp );
					$temp = preg_replace( "/\)/" , "\\)" , $temp );
					$seealso[1] = @preg_replace( "/$temp/" , "<a class='otherlink' href=\"javascript:searchExtra('$temp')\">$temp</a>" ,$seealso[1] );
					$seealso[1] = preg_replace( "/\\\/" , "" , $seealso[1] );			
				}

				$seealso = implode( "<br/><br/>See also" , $seealso );
				$def = $seealso;
			}				
			
			$title = preg_replace( "/\\\/" , "" , $title );
			print "<tr $syn><td><h3>$covered $title</h3><p>".nl2br($def)."</p><br/></td></tr>";
		}

		print "</table>";

		exit;
	}
}

if( isset($_GET['group']) )
{
	$term = mysql_real_escape_string($_GET['group']);
	$query = "select * from SoftwareTesting where term like '$term%' order by term ASC";	
	$results = $db->query($query,"array");

	print "<br /><br /><table class='results'>";

	foreach( $results as $result )
	{
		$title = ucfirst($result[1]);
		$def = $result[2];	
		$covered = ($result[3]=="1") ? "<img src='star.png' />" : "" ;
                $syn = (substr(trim($def),0,3) == "See") ? "class='dsynonyms'" : "";

		if(substr(trim($result[2]),0,3) == "See")
		{
			$link = $result[2];	
			$link = substr( $link , 4 , strlen($link) );
			$link = preg_match("/([a-zA-Z0-9 \-]*)/", $link, $match);	
			$link = preg_replace( "/\(/" , "\(" , $match[0] );
			$link = preg_replace( "/\)/" , "\)" , $link );						
			$def = @preg_replace( "/$link/" , "<a class='otherlink' href=\"javascript:searchExtra('$link')\">$link</a>" , $result[2] );
			$def = preg_replace( "/\\\/" , "" , $def );
			
		}	
		
		if ( stristr( $def , "See also" ) )
		{						
			$seealso = explode( "See also" , $def );
			$seealso[1] = eregi_replace( "\n" , "" , $seealso[1] );

			if( stristr( $seealso[1] , "," ) )
			{				
				$alsomore = explode( "," , $seealso[1] );
				
				for( $r = 0; $r < count( $alsomore ); $r++ )
				{					
					$temp = trim($alsomore[$r]);
					$temp =  stristr( $temp , "." ) ? substr( $temp , 0 , strlen($temp) -1 ) : $temp;
					$temp = preg_replace( "/\(/" , "\(" , $temp );
					$temp = preg_replace( "/\)/" , "\)" , $temp );
					$alsomore[$r] = @preg_replace( "/$temp/" , "<a class='otherlink' href=\"javascript:searchExtra('$temp')\">$temp</a>" , $alsomore[$r] );
					$malso[] = preg_replace( "/\\\/" , "" , $alsomore[$r] );
				}

				$seealso[1] = implode( "," , $malso );
			}
			else
			{
				$temp = trim( $seealso[1] );
				$temp =  stristr( $temp , "." ) ? substr( $temp , 0 , strlen($temp) -1 ) : $temp;
				$temp = preg_replace( "/\(/" , "\(" , $temp );
				$temp = preg_replace( "/\)/" , "\)" , $temp );
				$seealso[1] = @preg_replace( "/$temp/" , "<a class='otherlink' href=\"javascript:searchExtra('$temp')\">$temp</a>" ,$seealso[1] );
				$seealso[1] = preg_replace( "/\\\/" , "" , $seealso[1] );			
			}

			$seealso = implode( "<br/><br/>See also" , $seealso );
			$def = $seealso;
		}	

		print "<tr $syn><td class='data'><h3>$covered $title</h3><p>".nl2br($def)."</p><br/></td></tr>";
	}

	print "</table>";
	
	exit;
}

if( isset($_GET['all']) )
{
	$query = "select * from SoftwareTesting order by term ASC";
	$results = $db->query( $query , "array" );

	$termlist = array();

	$last = "";

	foreach( $results as $result )
	{
		$letter = ucfirst(substr(trim($result[1]),0,1));

		if( $letter != $last )
		{			
			$termlist[] = "<td class='h3'><h3>&nbsp;$letter</h3></td>";
			$last = $letter;
		}
		
		$syn = (substr(trim($result[2]),0,3) == "See") ? "class='synonyms'" : "";
		$syni = (substr(trim($result[2]),0,3) == "See") ? "class='isynonyms'" : "";
		$covered = ($result[3]=="1") ? "<img $syni src='star.png' />" : "" ;
		$termlist[] = "<td width='290' class='min'>$covered <a $syn href=\"javascript:search('".$result[1]."')\">".$result[1]."</a></td>";
		
	}

	$mid = ceil(count($termlist) / 4);

	print "<table class='tterms'>";

	$last = "";

	for($t=0; $t < $mid; $t++ )
	{		
		print "<tr>";
		print $termlist[$t];
		print $termlist[$mid + $t];
		print $termlist[$mid + $mid + $t];
		print $termlist[$mid + $mid + $mid + $t];
		print "</tr>";
	}

	print "</table>";
	
	exit;
}

if( isset( $_GET['testing'] ) )
{
	print "<table class='tterms'>";

	$query = "select * from SoftwareTesting where term LIKE '%testing' order by term ASC";
	$results = $db->query($query,"array");

	$termlist = array();

	$last = "";

	foreach( $results as $result )
	{
		$letter = ucfirst(substr(trim($result[1]),0,1));

		if( $letter != $last )
		{			
			$termlist[] = "<td class='h3'><h3>&nbsp;$letter</h3></td>";			
			$last = $letter;
		}
		
		$syn = (substr(trim($result[2]),0,3) == "See") ? " class='synonyms' " : " ";
		$syni = (substr(trim($result[2]),0,3) == "See") ? " class='isynonyms' " : " ";
		$covered = ($result[3]=="1") ? "<img $syni src='star.png' /> " : "" ;
		$termlist[] = "<td width='220' class='min'>$covered <a $syn href=\"javascript:searchExtra('".$result[1]."')\">".$result[1]."</a></td>";
		
	}

	$y = 0;
	$mid = ceil(count($termlist) / 2) -1;

	for($t=0; $t < $mid; $t++ )
	{
		print "<tr>";
		print $termlist[$t];
		print $termlist[$mid + $t];
		print "</tr>";
		$y += 2;
	}

	for( $o = $y; $o < count($termlist); $o++)
	{
		print "<tr>";
		print "<td></td>";
		print $termlist[$o];
		print "</tr>";
	}

	print "</table>";

	exit;
}

?>
<html>
<head>
<title>Software Testing terms</title>
<style>
body
{
	margin: 0px 0px 0px 0px;
	padding: 0px 0px 0px 0px;
}

a
{
	text-decoration:none;
	color: #222222;
}

.otherlink
{
	text-decoration:none;
	color: #bb0000;
}

.let
{
	text-decoration:none;
	color: #4E7FC8;
}


h2
{
	font-family: verdana, arial;
	font-size:10pt;
	color: #3666BB;
	margin-bottom: -5px;
}

h3
{
	font-family: verdana, arial;
	font-size:9pt;
	color: #4E7FC8;
	margin-bottom: -5px;
}


.h3
{
	border:1px solid #4E7FC8;
	padding-bottom: 10px;
	padding-left:5px;
}

p
{
	margin-bottom: -10px;
	margin-left: 30px;
	font-family: arial, verdana;
	font-size:9pt;
	color: #222222;
	
}

.min
{
	font-family: verdana, arial;
	font-size:8pt;
	color: #222222;
	padding-left:5px;
}

.match
{
	font-family: arial, verdana;
	font-size:9pt;
	background-color:#FEF9B5;
	color: #222222;
}

.matchh
{
	font-family: verdana, arial;
	font-size:9pt;
	background-color:#FEF9B5;
	color: #222222;
}

table 
{
	border-collapse: collapse; // 'cellspacing' equivalent
}

.tterms, .tterms td
{
	margin:3px;
	border-spacing:3px; 
	border-collapse:separate;
}

.results
{
	width:700px;
	margin-left:20px;
	margin-right:20px;
}

.table
{
	width: 100%;
	color: #000000;
	background-color: #ffffff;
	font-family: verdana, arial;
	border: 0px;
	margin: 0px 0px 0px 0px;
	border-spacing: 0px;
}

.col
{
	background-color: #ffffff;
	font-family: verdana, arial;
	color: #000000;
	border: 0px;
	margin: 0px 0px 0px 0px;
	border-spacing: 0px;
	padding: 0px 0px 0px 0px;
	
}

.covered
{
	color:#550000;
	font-weight:bold;
	font-size: 9pt;
}

.synonyms
{
	color:#222222;
	font-size: 8pt;
}

.covered1
{
	color:#222222;
	font-weight:bold;
	font-size: 9pt;
}
img
{
	border:0px;
}

.searchbox
{
	padding:2px 2px 2px 2px;
}

.minheight
{
	min-height:800px;
     	height:auto !important;
     	height:800px; 
}

</style>
<script type="text/javascript" src="jquery.min.js"></script>
<script language='javascript' type='text/javascript'>

function set_cookie ( name, value, exp_y, exp_m, exp_d, path, domain, secure )
{
	var cookie_string = name + "=" + escape ( value );
	if ( exp_y )
	{
		var expires = new Date ( exp_y, exp_m, exp_d );
		cookie_string += "; expires=" + expires.toGMTString();
	}
	if ( path )
		cookie_string += "; path=" + escape ( path );

	if ( domain )
		cookie_string += "; domain=" + escape ( domain );

	if ( secure )
		cookie_string += "; secure";

	document.cookie = cookie_string;
}

function getCookie(c_name)
{
	if (document.cookie.length>0)
	{
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1)
		{
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
	
			return unescape(document.cookie.substring(c_start,c_end));
		}
	}
	return "";
}


set_cookie('syn','false');

var xhr = null;
var resultsTimer = null;
var all = false;
var hist = new Array();
var histcount = -1;
var histbool = false;


function hhistory( val )
{
	histcount++; 
	hist[histcount] = val;
	
}


function hback()
{	
	if(histcount == 0)
		return;
	
	histcount--;
	histbool = true;

	var where =  hist[histcount].split('|');
	
	if(where[0]=="get")
	{
		$("#searchTerm").val(where[1]);
		$("#searchTerm2").val(where[2]);
		get();
	}
	else
	{
		showGroup( where[1] );
	}
}


function search( val )
{
	$("#searchTerm").val(val);
	$("#searchTerm2").val("");
	showAll();
	get();		
}


function searchExtra( val )
{
	$("#searchTerm").val(val);
	$("#searchTerm2").val("");
	get();		
}



function get()
{	
	$("#countdown1").html("<img src='countdown.gif' />");
	$("#countdown2").html("<img src='countdown.gif' />");

	clearTimeout( resultsTimer );
	
	if (xhr)
	{
		xhr.abort();
	} 

	resultsTimer = setTimeout(
		function(){
			$("#countdown1").html("<img src='ncountdown.gif' />");
			$("#countdown2").html("<img src='ncountdown.gif' />");
			$("#result").html("<div align='center'><br /><br /><br /><br /><br /><br /><img src='big.gif' /></div>");
			xhr = $.get("index.php", 
			{ 
				ajax: "true", 
				searchTerm: $("#searchTerm").val(),
				searchTerm2: $("#searchTerm2").val(),
				expr: $("#exp").val()
				}, 
				function(data)
				{
					if(data!="true")
					{			
						$("#result").html(data);
						hideSynonymsUpdate();	
						if( histbool == false )
						{
							hhistory( "get|" + $("#searchTerm").val() + "|" + $("#searchTerm2").val() );		    	   
						}
						else
						{
						    	histbool = false;
						}
					}
					else
					{
						$("#result").html("fail");
					}
		   		}
			);
		},
		1000
	);	
}


function showGroup( val )
{
	$("#result").html("<div align='center'><br /><br /><br /><br /><br /><br /><img src='big.gif' /></div>");

	$.get("index.php", 
	{ 
		ajax: "true", 
		group: val
		}, 
		function(data)
		{
			if(data!="true")
			{			
				$("#result").html(data);	
				if( histbool == false )
				{
					hhistory( "showGroup|" + val);
				}
				else
				{
				    	histbool = false;
				}
				hideSynonymsUpdate();		    	   
			}
			else
			{
				$("#result").html("fail");
			}
   		}
	);
}



function showAll()
{	
	
	if(all == false)
	{
		all = true;

		$.get("index.php", 
		{ 
			ajax: "true", 
			testing: "true"
			}, 
			function(data)
			{
				if(data!="true")
				{									
					$("#content").show(2000, function () 
				        {
						$("#showAll").text("Complete Listing");
						$("#termsList").html(data);					
						hideSynonymsUpdate();	
				        });    	   
				}
				else
				{
					$("#result").html("fail");
				}
	   		}
		);
	}
	else
	{
		all = false;		
		
		$.get("index.php", 
		{ 
			ajax: "true", 
			all: "true"
			}, 
			function(data)
			{
				if(data!="true")
				{		
					$("#termsList").html(data);
					$("#content").hide(2000, function () 
				        {
						$("#showAll").text("Hide Complete Listing");							
						hideSynonymsUpdate();	
				        });
				        									    	   
				}
				else
				{
					$("#result").html("fail");
				}
	   		}
		);		
	}
}



function hideSynonyms()
{
	var cook = getCookie('syn');

	if ( cook == "false" )
	{
		set_cookie('syn','true');
		hideSynonymsUpdate();
	}
	else
	{
		set_cookie('syn','false');
		hideSynonymsUpdate();
	}
}


function hideSynonymsUpdate()
{
	var cook = getCookie('syn');
	if ( cook == "true" )
	{
		$("#SynonymsLink").text("Show Synonyms");
		$(".synonyms").css("color","#ffffff");
                $(".isynonyms").hide();
                $(".dsynonyms").hide();
	}
	else
	{
		$("#SynonymsLink").text("Hide Synonyms");
		$(".synonyms").css("color","#222222");
                $(".isynonyms").show();
                $(".dsynonyms").show();
	}
}


$(document).ready(function()
{		
	$("#searchTerm").keyup(get);	
	$("#searchTerm2").keyup(get);	
	showAll();	
	showGroup('a');	
});
</script>
</head>
<body>
<table class='table'>
	<tr>
		<td colspan='2' style="padding-left:5px;padding-top:10px;padding-bottom:10px;font-size:10pt; vertical-align:middle; background-color:#4E7FC8; color:#ffffff"><a name='top'>&nbsp;</a> <a href='javascript:hback()' style='padding-right:10px;'><img src='back-icon.png' /></a>
		Search for definition : <input type='text' name='searchTerm' id='searchTerm' size='30' class='searchbox'> <span id='countdown1'><img src='ncountdown.gif' /></span>  <select name='exp' id='exp'> <option value='1'>and</option><option value='2'>or</option></select> <input type='text' name='searchTerm2' id='searchTerm2' size='30' class='searchbox'> <span id='countdown2' style='margin-right:120px'><img src='ncountdown.gif' /></span>
		<a href='javascript:hideSynonyms()' id='SynonymsLink' style='color:#ffffff;text-decoration:underline'>Hide Synonyms</a> &nbsp;&nbsp; <a href="javascript:showAll()" id='showAll' style='color:#ffffff;text-decoration:underline'>Complete Listing</a>	
		</td>
	</tr>
	<tr>
		<td valign='top' class='col' id='resultCol' style="border-left: 5px solid #4E7FC8;">
			<div class='minheight' id='content'>
				<div style="padding-left:25px;padding-top:10px" id='letters'>
					<a class='let' href="javascript:showGroup('a')">A</a> 
					<a class='let' href="javascript:showGroup('b')">B</a> 
					<a class='let' href="javascript:showGroup('c')">C</a> 
					<a class='let' href="javascript:showGroup('d')">D</a> 
					<a class='let' href="javascript:showGroup('e')">E</a> 
					<a class='let' href="javascript:showGroup('f')">F</a> 
					<a class='let' href="javascript:showGroup('g')">G</a> 
					<a class='let' href="javascript:showGroup('h')">H</a> 
					<a class='let' href="javascript:showGroup('i')">I</a> 
					<a class='let' href="javascript:showGroup('j')">J</a> 
					<a class='let' href="javascript:showGroup('k')">K</a> 
					<a class='let' href="javascript:showGroup('l')">L</a> 
					<a class='let' href="javascript:showGroup('m')">M</a> 
					<a class='let' href="javascript:showGroup('n')">N</a> 
					<a class='let' href="javascript:showGroup('o')">O</a> 
					<a class='let' href="javascript:showGroup('p')">P</a> 
					<a class='let' href="javascript:showGroup('q')">Q</a> 
					<a class='let' href="javascript:showGroup('r')">R</a> 
					<a class='let' href="javascript:showGroup('s')">S</a> 
					<a class='let' href="javascript:showGroup('t')">T</a> 
					<a class='let' href="javascript:showGroup('u')">U</a> 
					<a class='let' href="javascript:showGroup('v')">V</a> 
					<a class='let' href="javascript:showGroup('w')">W</a>
					<a class='let' href="javascript:showGroup('x')">X</a> 
					<a class='let' href="javascript:showGroup('y')">Y</a> 
					<a class='let' href="javascript:showGroup('z')">Z</a> 
				</div>
				<div style='width:740px' id='result'>

				</div>
			</div>
		</td>
		<td valign='top' style="border-left: 3px solid #4E7FC8; border-right: 5px solid #4E7FC8; padding:5px;">				
			<div class='minheight' id='termsList'>
				
			</div>
			<br />
		</td>
	</tr>
	<tr>
		<td colspan='2' style="padding-left:30px;padding-top:10px;padding-bottom:10px;font-size:10pt; vertical-align:middle; background-color:#4E7FC8; color:#ffffff">
		<a href='#top' style='color:#ffffff;text-decoration:underline'>Top</a>
		</td>
	</tr>
</table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1014155-1");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>

